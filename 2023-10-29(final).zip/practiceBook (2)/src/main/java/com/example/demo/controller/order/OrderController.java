package com.example.demo.controller.order;

import java.util.*;

import javax.servlet.http.*;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.dto.cart.*;

@Controller
public class OrderController {
	
	
	// 1. 주문 페이지 보여주기
	@GetMapping("/order")
	public ModelAndView order(HttpServletRequest request) {
		HttpSession session = request.getSession();
		
		List<CartDto.Select> cartList =(List<CartDto.Select>)session.getAttribute("cartList");
		
		return new ModelAndView("order_page").addObject("cartList", cartList);
	}
	
}
